// alert()

document.getElementById("GetUserNameBtn-main").addEventListener("click",()=>{
    document.getElementById("loader-container").classList.add("display-flex");
});